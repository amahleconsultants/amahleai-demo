import { useState } from "react";
import { Sparkles } from "lucide-react";

export default function Home() {
  const [query, setQuery] = useState("");
  const [answer, setAnswer] = useState("");

  const responses = {
    compliance:
      "To register your business with CIPC, you need your ID, address proof, and a unique business name. Start at www.cipc.co.za. I can generate a checklist for you.",
    marketing:
      "Digital marketing starts with branding. Define your niche, then use platforms like Instagram, TikTok, and WhatsApp Business. I can give you a 5-day content plan.",
    pr:
      "You can write a press release highlighting your brand story. I can generate a media-ready draft and even recommend media contacts.",
    indigenous:
      "In isiZulu, 'Ubuntu' means 'I am because we are' – a principle of collective community. I can share more proverbs or traditional practices if you'd like.",
  };

  const handleAsk = () => {
    const key = query.toLowerCase();
    if (key.includes("compliance")) setAnswer(responses.compliance);
    else if (key.includes("marketing")) setAnswer(responses.marketing);
    else if (key.includes("pr")) setAnswer(responses.pr);
    else if (key.includes("indigenous")) setAnswer(responses.indigenous);
    else
      setAnswer(
        "Sorry, I'm still learning. Can you rephrase your question?"
      );
  };

  return (
    <div style={{ padding: "2rem", maxWidth: 600, margin: "auto" }}>
      <h1 style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
        <Sparkles color="#7C3AED" size={32} /> AmahleAI Demo
      </h1>
      <p>Ask about business compliance, marketing, PR, or indigenous knowledge.</p>
      <div style={{ display: "flex", gap: "0.5rem", margin: "1rem 0" }}>
        <input
          style={{ flex: 1, padding: "0.5rem" }}
          placeholder="e.g., How do I register my business?"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button onClick={handleAsk}>Ask</button>
      </div>
      {answer && (
        <div style={{ background: "#f5f5f5", padding: "1rem" }}>{answer}</div>
      )}
    </div>
  );
}